from django.http import HttpResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout
from django.contrib import messages
from .forms import RegistrationForm, LoginForm
from django.contrib.auth.decorators import login_required
from .models import Request, CustomUser

def home_view(request):
    return render(request, 'home.html')

def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request, data=request.POST)  # Use custom LoginForm here
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, 'Login successful!')
            return redirect('home')
        else:
            messages.error(request, 'Invalid username or password')
    else:
        form = LoginForm()
    return render(request, 'login.html', {'form': form})

def register_view(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Registration successful! You are now logged in.')
            return redirect('home')
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = RegistrationForm()
    return render(request, 'register.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('home')

@login_required
def donors_view(request):
    user = request.user
    users = CustomUser.objects.filter(blood_group=user.blood_group).exclude(id=user.id)
    return render(request, 'donors.html', {'users': users})

@login_required
def request_view(request, user_id):
    sender = request.user.id
    receiver = user_id
    request = Request.objects.create(sender=sender, receiver=receiver)
    return redirect('requests')

@login_required
def requests_view(request):
    # Fetch all requests sent by the logged-in user
    requests_sent = Request.objects.filter(sender=request.user.id)
    requests_sent_refined = [
        {
            "request": req,
            "receiver": CustomUser.objects.get(id=req.receiver)  # Fetch full receiver details
        }
        for req in requests_sent
    ]

    # Fetch all requests received by the logged-in user
    requests_received = Request.objects.filter(receiver=request.user.id)
    requests_received_refined = [
        {
            "request": req,
            "sender": CustomUser.objects.get(id=req.sender)  # Fetch full sender details
        }
        for req in requests_received
    ]

    # Render the template with refined data
    return render(request, 'requests.html', {
        'requests_sent': requests_sent_refined,
        'requests_received': requests_received_refined,
    })
